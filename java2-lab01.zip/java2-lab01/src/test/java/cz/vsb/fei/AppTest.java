package cz.vsb.fei;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Unit test for simple App.
 */
class AppTest {

	/**
	 * Rigorous Test :-)
	 */
	@Test
	void shouldAnswerWithTrue() {
		assertTrue(true);
	}
}
