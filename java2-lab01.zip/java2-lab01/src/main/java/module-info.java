module cz.vsb.fei {
    requires transitive javafx.controls;
    requires javafx.fxml;
	requires static lombok;
	requires org.apache.logging.log4j;
    requires cz.vsb.fei.java2.lab01text2asciiart;
    opens cz.vsb.fei to javafx.fxml;
    exports cz.vsb.fei;
}